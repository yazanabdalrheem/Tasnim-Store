import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.91.1";

const PAYPAL_CLIENT_ID = Deno.env.get("PAYPAL_CLIENT_ID") || "";
const PAYPAL_CLIENT_SECRET = Deno.env.get("PAYPAL_CLIENT_SECRET") || "";
const PAYPAL_ENV = Deno.env.get("PAYPAL_ENV") || "sandbox";
const PAYPAL_API = PAYPAL_ENV === "live"
    ? "https://api-m.paypal.com"
    : "https://api-m.sandbox.paypal.com";

const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req) => {
    if (req.method === "OPTIONS") {
        return new Response("ok", { headers: corsHeaders });
    }

    try {
        const { action, cartItems, couponCode, userData, orderID } = await req.json();

        const supabase = createClient(
            Deno.env.get("SUPABASE_URL") ?? "",
            Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
        );

        // Get Auth Token
        const getAccessToken = async () => {
            const auth = btoa(`${PAYPAL_CLIENT_ID}:${PAYPAL_CLIENT_SECRET}`);
            const response = await fetch(`${PAYPAL_API}/v1/oauth2/token`, {
                method: "POST",
                body: "grant_type=client_credentials",
                headers: {
                    Authorization: `Basic ${auth}`,
                    "Content-Type": "application/x-www-form-urlencoded",
                },
            });
            const data = await response.json();
            return data.access_token;
        };

        if (action === "create-order") {
            // 1. Calculate Total (Securely)
            let subtotal = 0;
            for (const item of cartItems) {
                const { data: product } = await supabase
                    .from("products")
                    .select("price, discount_price")
                    .eq("id", item.product_id)
                    .single();

                if (product) {
                    const price = product.discount_price || product.price;
                    subtotal += price * item.quantity;
                }
            }

            // 2. Validate Coupon
            let discount = 0;
            if (couponCode) {
                const { data: couponData } = await supabase.rpc("validate_coupon", {
                    p_code: couponCode,
                    p_subtotal: subtotal
                });
                if (couponData?.valid) {
                    discount = couponData.discount_amount;
                }
            }

            const total = Math.max(0, subtotal - discount);

            // 3. Create PayPal Order
            const accessToken = await getAccessToken();
            const response = await fetch(`${PAYPAL_API}/v2/checkout/orders`, {
                method: "POST",
                headers: {
                    Authorization: `Bearer ${accessToken}`,
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    intent: "CAPTURE",
                    purchase_units: [
                        {
                            amount: {
                                currency_code: "ILS",
                                value: total.toFixed(2),
                            },
                            description: `Tasnim Store Order`,
                        },
                    ],
                }),
            });

            const data = await response.json();
            return new Response(JSON.stringify(data), {
                headers: { ...corsHeaders, "Content-Type": "application/json" },
                status: 200,
            });
        }

        if (action === "capture-order") {
            const accessToken = await getAccessToken();
            const response = await fetch(`${PAYPAL_API}/v2/checkout/orders/${orderID}/capture`, {
                method: "POST",
                headers: {
                    Authorization: `Bearer ${accessToken}`,
                    "Content-Type": "application/json",
                },
            });

            const captureData = await response.json();

            if (captureData.status === "COMPLETED") {
                // Create Order in DB
                const { data: orderData, error: orderError } = await supabase
                    .from("orders")
                    .insert([{
                        user_id: userData.userId || null,
                        total_amount: parseFloat(captureData.purchase_units[0].payments.captures[0].amount.value),
                        status: "paid",
                        customer_details: userData.customerDetails,
                        shipping_address: userData.shippingAddress,
                        transaction_id: captureData.id,
                        payment_method: "paypal"
                    }])
                    .select()
                    .single();

                if (orderError) throw orderError;

                // Insert Items
                const orderItems = cartItems.map((item: any) => ({
                    order_id: orderData.id,
                    product_id: item.product_id,
                    quantity: item.quantity,
                    price_at_purchase: item.price
                }));

                await supabase.from("order_items").insert(orderItems);

                return new Response(JSON.stringify({ success: true, orderData }), {
                    headers: { ...corsHeaders, "Content-Type": "application/json" },
                    status: 200,
                });
            }

            return new Response(JSON.stringify(captureData), {
                headers: { ...corsHeaders, "Content-Type": "application/json" },
                status: 400,
            });
        }

        return new Response("Invalid action", {
            headers: corsHeaders,
            status: 400
        });

    } catch (error: any) {
        return new Response(JSON.stringify({ error: error.message }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
            status: 500,
        });
    }
});
