-- Enable Extensions
create extension if not exists "uuid-ossp";

-- 1. Profiles (Users & Roles)
create type user_role as enum ('customer', 'admin', 'super_admin');

create table public.profiles (
  id uuid references auth.users not null primary key,
  full_name text,
  email text,
  phone text,
  role user_role default 'customer',
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- RLS for Profiles
alter table public.profiles enable row level security;
create policy "Public profiles are viewable by everyone" on profiles for select using (true);
create policy "Users can insert their own profile" on profiles for insert with check (auth.uid() = id);
create policy "Users can update own profile" on profiles for update using (auth.uid() = id);

-- 2. Products & Categories
create table public.categories (
  id uuid default uuid_generate_v4() primary key,
  name_he text not null,
  name_ar text,
  name_en text,
  slug text unique,
  image_url text,
  created_at timestamp with time zone default timezone('utc'::text, now())
);

create table public.products (
  id uuid default uuid_generate_v4() primary key,
  category_id uuid references public.categories(id),
  name_he text not null,
  name_ar text,
  name_en text,
  description_he text,
  description_ar text,
  description_en text,
  price numeric not null,
  discount_price numeric,
  stock_quantity integer default 0,
  is_active boolean default true,
  images text[], -- Array of image URLs
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- 3. Appointments
create table public.appointments (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.profiles(id),
  start_time timestamp with time zone not null,
  end_time timestamp with time zone not null,
  type text not null, -- 'eye_exam', 'contact_lenses', etc.
  status text default 'pending', -- pending, confirmed, cancelled, completed
  customer_name text,
  customer_phone text,
  customer_email text,
  notes text,
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- 4. Orders
create table public.orders (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.profiles(id),
  total_amount numeric not null,
  status text default 'pending', -- pending, paid, shipped, completed, cancelled
  shipping_address jsonb,
  customer_details jsonb,
  created_at timestamp with time zone default timezone('utc'::text, now())
);

create table public.order_items (
  id uuid default uuid_generate_v4() primary key,
  order_id uuid references public.orders(id) on delete cascade,
  product_id uuid references public.products(id),
  quantity integer not null,
  price_at_purchase numeric not null
);

-- 5. Content & Settings (The "Single Source of Truth")
create table public.site_settings (
  id uuid default uuid_generate_v4() primary key,
  key text unique not null,
  value jsonb not null,
  created_at timestamp with time zone default timezone('utc'::text, now())
);
-- Examples: 'store_info', 'business_hours', 'hero_content', 'social_links'

create table public.faq (
  id uuid default uuid_generate_v4() primary key,
  question_he text,
  question_ar text,
  question_en text,
  answer_he text,
  answer_ar text,
  answer_en text,
  category text,
  display_order integer default 0,
  is_public boolean default true,
  created_at timestamp with time zone default timezone('utc'::text, now())
);

create table public.questions (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.profiles(id),
  question text not null,
  answer text,
  is_public boolean default false,
  status text default 'pending', -- pending, answered
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- Enable RLS for everything (simplified for initial setup, refine later)
alter table categories enable row level security;
alter table products enable row level security;
alter table appointments enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;
alter table site_settings enable row level security;
alter table faq enable row level security;
alter table questions enable row level security;

-- Public Read Policies
create policy "Public read categories" on categories for select using (true);
create policy "Public read products" on products for select using (is_active = true);
create policy "Public read settings" on site_settings for select using (true);
create policy "Public read faq" on faq for select using (is_public = true);
create policy "Public read questions" on questions for select using (is_public = true);

-- Admin Policies (Needs a function to check role, for now assuming manual management or specific user checks)
-- This is a placeholder. In production, use a proper `is_admin()` function
create policy "Admins all access" on products for all using (auth.jwt() ->> 'email' = 'admin@tasnim.com'); -- Replace with real logic
- -   1 .   E n a b l e   R L S  
 A L T E R   T A B L E   p u b l i c . o r d e r s   E N A B L E   R O W   L E V E L   S E C U R I T Y ;  
 A L T E R   T A B L E   p u b l i c . o r d e r _ i t e m s   E N A B L E   R O W   L E V E L   S E C U R I T Y ;  
  
 - -   2 .   D r o p   e x i s t i n g   p o l i c i e s   t o   a v o i d   c o n f l i c t s  
 D R O P   P O L I C Y   I F   E X I S T S   " P u b l i c   i n s e r t   o r d e r s "   O N   p u b l i c . o r d e r s ;  
 D R O P   P O L I C Y   I F   E X I S T S   " P u b l i c   i n s e r t   i t e m s "   O N   p u b l i c . o r d e r _ i t e m s ;  
 D R O P   P O L I C Y   I F   E X I S T S   " A d m i n s   a l l   a c c e s s "   O N   p u b l i c . o r d e r s ;  
 D R O P   P O L I C Y   I F   E X I S T S   " E n a b l e   r e a d   a c c e s s   f o r   a l l   u s e r s "   O N   " p u b l i c " . " o r d e r s " ;  
 D R O P   P O L I C Y   I F   E X I S T S   " E n a b l e   i n s e r t   f o r   a l l   u s e r s "   O N   " p u b l i c " . " o r d e r s " ;  
 D R O P   P O L I C Y   I F   E X I S T S   " E n a b l e   r e a d   a c c e s s   f o r   a l l   u s e r s "   O N   " p u b l i c " . " o r d e r _ i t e m s " ;  
 D R O P   P O L I C Y   I F   E X I S T S   " E n a b l e   i n s e r t   f o r   a l l   u s e r s "   O N   " p u b l i c " . " o r d e r _ i t e m s " ;  
  
 - -   3 .   P o l i c i e s   f o r   O R D E R S   t a b l e  
  
 - -   A .   P u b l i c / G u e s t   I N S E R T   ( T r u e )  
 C R E A T E   P O L I C Y   " P u b l i c   c a n   i n s e r t   o r d e r s "  
 O N   p u b l i c . o r d e r s  
 F O R   I N S E R T  
 W I T H   C H E C K   ( t r u e ) ;  
  
 - -   B .   A d m i n   F U L L   A C C E S S   ( S e l e c t ,   I n s e r t ,   U p d a t e ,   D e l e t e )  
 C R E A T E   P O L I C Y   " A d m i n s   h a v e   f u l l   c o n t r o l   o n   o r d e r s "  
 O N   p u b l i c . o r d e r s  
 F O R   A L L  
 U S I N G   (  
     E X I S T S   (  
         S E L E C T   1   F R O M   p u b l i c . p r o f i l e s  
         W H E R E   p r o f i l e s . i d   =   a u t h . u i d ( )    
         A N D   p r o f i l e s . r o l e   I N   ( ' a d m i n ' ,   ' s u p e r _ a d m i n ' )  
     )  
 ) ;  
  
 - -   4 .   P o l i c i e s   f o r   O R D E R _ I T E M S   t a b l e  
  
 - -   A .   P u b l i c / G u e s t   I N S E R T   ( T r u e )  
 C R E A T E   P O L I C Y   " P u b l i c   c a n   i n s e r t   o r d e r   i t e m s "  
 O N   p u b l i c . o r d e r _ i t e m s  
 F O R   I N S E R T  
 W I T H   C H E C K   ( t r u e ) ;  
  
 - -   B .   A d m i n   F U L L   A C C E S S  
 C R E A T E   P O L I C Y   " A d m i n s   h a v e   f u l l   c o n t r o l   o n   o r d e r   i t e m s "  
 O N   p u b l i c . o r d e r _ i t e m s  
 F O R   A L L  
 U S I N G   (  
     E X I S T S   (  
         S E L E C T   1   F R O M   p u b l i c . p r o f i l e s  
         W H E R E   p r o f i l e s . i d   =   a u t h . u i d ( )    
         A N D   p r o f i l e s . r o l e   I N   ( ' a d m i n ' ,   ' s u p e r _ a d m i n ' )  
     )  
 ) ;  
 