import SEO from '../components/SEO';


export default function PrivacyPolicy() {
    return (
        <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
            <SEO title="Privacy Policy" description="Privacy Policy for Tasnim Optic" />
            <div className="max-w-3xl mx-auto bg-white p-8 rounded-2xl shadow-sm space-y-6">
                <h1 className="text-3xl font-bold text-gray-900 border-b pb-4">Privacy Policy</h1>

                <section className="space-y-4">
                    <p className="text-gray-600">Last updated: {new Date().toLocaleDateString()}</p>
                    <p className="text-gray-700 leading-relaxed">
                        At Tasnim Optic, we take your privacy seriously. This Privacy Policy explains how we collect, use, and protect your personal information when you use our website and services.
                    </p>
                </section>

                <section className="space-y-3">
                    <h2 className="text-xl font-semibold text-gray-800">1. Information We Collect</h2>
                    <p className="text-gray-600 text-sm">We collect information you provide directly to us, such as when you create an account, make a purchase, or book an appointment. This includes:</p>
                    <ul className="list-disc list-inside text-gray-600 text-sm pl-4">
                        <li>Name and contact information (email, phone number)</li>
                        <li>Shipping and billing addresses</li>
                        <li>Appointment details and optical prescriptions (if provided)</li>
                    </ul>
                </section>

                <section className="space-y-3">
                    <h2 className="text-xl font-semibold text-gray-800">2. How We Use Your Information</h2>
                    <p className="text-gray-600 text-sm">We use data to:</p>
                    <ul className="list-disc list-inside text-gray-600 text-sm pl-4">
                        <li>Process your orders and bookings</li>
                        <li>Send order updates and appointment reminders</li>
                        <li>Improve our store services and user experience</li>
                    </ul>
                </section>

                <section className="space-y-3">
                    <h2 className="text-xl font-semibold text-gray-800">3. Contact Us</h2>
                    <p className="text-gray-600 text-sm">
                        If you have questions about this policy, please contact us at support@tasnimoptic.com.
                    </p>
                </section>
            </div>
        </div>
    );
}
