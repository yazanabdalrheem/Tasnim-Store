import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import { Award, Heart, Users, CheckCircle, Eye, MessageCircle, Star } from "lucide-react";
import { clsx } from "clsx";
import { Button } from "../components/ui/Button";

export default function About() {
    const { t, i18n } = useTranslation();
    const isRTL = i18n.dir() === 'rtl';

    const features = [
        {
            icon: Award,
            title: t("about.features.custom.title", "Personalized Customization"),
            desc: t("about.features.custom.desc", "Every client receives a unique solution tailored to their eyes.")
        },
        {
            icon: Heart,
            title: t("about.features.care.title", "Personal Care"),
            desc: t("about.features.care.desc", "Warm, human, and professional service.")
        },
        {
            icon: Users,
            title: t("about.features.ages.title", "All Ages Experience"),
            desc: t("about.features.ages.desc", "Children, adults, and seniors.")
        },
        {
            icon: CheckCircle,
            title: t("about.features.precision.title", "Precision & Professionalism"),
            desc: t("about.features.precision.desc", "Advanced exams with clear explanations.")
        }
    ];

    return (
        <div className="min-h-screen bg-slate-50 relative overflow-hidden">
            {/* Subtle Texture */}
            <div className="absolute inset-0 bg-[radial-gradient(#cbd5e1_1px,transparent_1px)] [background-size:20px_20px] opacity-[0.3] pointer-events-none" />

            {/* HERO SECTION */}
            <section className="relative pt-24 pb-20 px-4 md:px-8">
                <div className="container mx-auto max-w-5xl text-center relative z-10">
                    <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-50 text-blue-700 text-sm font-bold border border-blue-100 mb-6 shadow-sm animate-fade-in-up">
                        <Star size={16} fill="currentColor" />
                        {t("about.badge", "Certified Optometrist")}
                    </div>

                    <h1 className="text-4xl md:text-6xl font-bold text-slate-900 mb-8 font-heading tracking-tight leading-tight animate-fade-in-up delay-100">
                        {t("about.title", "Meet Tasnim Optic")}
                    </h1>

                    <div className="max-w-3xl mx-auto bg-white/80 backdrop-blur-md p-8 md:p-12 rounded-[32px] shadow-xl border border-white/50 animate-fade-in-up delay-200">
                        <p className="text-xl md:text-2xl text-slate-700 leading-relaxed font-light">
                            {t("about.intro", "My name is Tasnim Abbas, a certified optometrist with a B.Sc in Vision Sciences from Bar-Ilan University. Over 5 years of clinical experience in optometry, eye exams, and fitting advanced vision solutions.")}
                        </p>
                    </div>
                </div>
            </section>

            {/* FEATURES GRID */}
            <section className="py-16 px-4">
                <div className="container mx-auto max-w-6xl">
                    <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">
                        {t("about.whyChooseMe", "What Sets Me Apart?")}
                    </h2>

                    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                        {features.map((feature, idx) => (
                            <div
                                key={idx}
                                className="bg-white p-8 rounded-[24px] shadow-sm hover:shadow-lg transition-all border border-slate-100 hover:-translate-y-1 group"
                            >
                                <div className="w-14 h-14 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-900 group-hover:bg-primary group-hover:text-white transition-colors mb-6">
                                    <feature.icon size={28} />
                                </div>
                                <h3 className="text-xl font-bold text-slate-900 mb-3 text-start">
                                    {feature.title}
                                </h3>
                                <p className="text-slate-500 leading-relaxed text-start">
                                    {feature.desc}
                                </p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* STATS (Optional) */}
            <section className="py-12 border-y border-slate-200 bg-white/50 backdrop-blur-sm">
                <div className="container mx-auto max-w-4xl flex flex-wrap justify-center gap-12 md:gap-24">
                    <div className="text-center">
                        <div className="text-4xl font-bold text-primary mb-1">5+</div>
                        <div className="text-sm font-bold text-slate-500 uppercase tracking-widest">{t("about.stats.years", "Years Experience")}</div>
                    </div>
                    <div className="text-center">
                        <div className="text-4xl font-bold text-primary mb-1">B.Sc</div>
                        <div className="text-sm font-bold text-slate-500 uppercase tracking-widest">{t("about.stats.degree", "Vision Sciences")}</div>
                    </div>
                    <div className="text-center">
                        <div className="text-4xl font-bold text-primary mb-1">100%</div>
                        <div className="text-sm font-bold text-slate-500 uppercase tracking-widest">{t("about.stats.care", "Personal Care")}</div>
                    </div>
                </div>
            </section>

            {/* FOOTER CTA */}
            <section className="py-24 px-4 text-center">
                <div className="container mx-auto max-w-3xl">
                    <h2 className="text-3xl md:text-5xl font-bold text-slate-900 mb-8 font-heading">
                        {t("about.mission", "Your Vision — My Mission")}
                    </h2>

                    <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                        <Link to="/book-exam" className="w-full sm:w-auto">
                            <Button className="w-full h-[56px] text-lg px-8 rounded-xl shadow-lg hover:shadow-primary/30">
                                <Eye size={20} className={clsx("mr-2", isRTL && "ml-2 mr-0")} />
                                {t("home.bookEyeExam", "Book Eye Exam")}
                            </Button>
                        </Link>

                        <Link to="/ask" className="w-full sm:w-auto">
                            <Button variant="outline" className="w-full h-[56px] text-lg px-8 rounded-xl bg-white hover:bg-slate-50">
                                <MessageCircle size={20} className={clsx("mr-2", isRTL && "ml-2 mr-0")} />
                                {t("about.askDetails", "Ask Tasnim")}
                            </Button>
                        </Link>
                    </div>
                </div>
            </section>
        </div>
    );
}
